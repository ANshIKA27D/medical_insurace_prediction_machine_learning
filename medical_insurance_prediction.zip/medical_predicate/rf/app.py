import numpy as np
import joblib
import streamlit as st
import os

# Get the current directory path
current_dir = os.path.dirname(os.path.abspath(__file__))

# Load model with absolute path
model = joblib.load(os.path.join(current_dir, 'MIPML.pkl'))

# --- CSS Styling ---
st.markdown("""
    <style>
    body {
        background: #0a0c10;
        color: #e6e6e6;
        font-family: 'Segoe UI', sans-serif;
    }
    .stApp {
        background: linear-gradient(145deg, #111318 0%, #0d1117 100%);
        padding: 2.5rem;
        max-width: 1000px;
        margin: 0 auto;
        border-radius: 20px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .logo-container img {
        width: 750px;
        height: 250px;
        border-radius: 20px;
        filter: drop-shadow(0 0 15px rgba(42,161,152,0.4));
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0% { transform: scale(1); filter: brightness(1) drop-shadow(0 0 15px rgba(42,161,152,0.3)); }
        50% { transform: scale(1.05); filter: brightness(1.2) drop-shadow(0 0 20px rgba(42,161,152,0.5)); }
        100% { transform: scale(1); filter: brightness(1) drop-shadow(0 0 15px rgba(42,161,152,0.3)); }
    }
    .avatar-container {
        text-align: center;
        margin: 2rem auto;
        padding: 2rem;
        max-width: 200px;
        background: rgba(255, 255, 255, 0.03);
        border-radius: 15px;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.05);
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
    }
    .avatar-container img {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        box-shadow: 0 8px 32px rgba(42,161,152,0.3);
        border: 3px solid #2aa198;
    }
    h1 {
        color: #2aa198;
        text-align: center;
        font-size: 2.5rem;
        margin: 1.5rem 0;
        text-shadow: 0 0 10px rgba(42,161,152,0.3);
    }
    h2 {
        color: #2aa198;
        font-size: 1.8rem;
        margin-bottom: 1.5rem;
        text-shadow: 0 0 8px rgba(42,161,152,0.2);
    }
    .stSelectbox, .stSlider {
        background: rgba(255, 255, 255, 0.03);
        border-radius: 10px;
        padding: 1.5rem;
        margin: 1rem 0;
        border: 1px solid rgba(255, 255, 255, 0.05);
    }
    .stSelectbox:hover, .stSlider:hover {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(42,161,152,0.2);
    }
    .stButton>button {
        background: linear-gradient(135deg, #2aa198 0%, #1e8c84 100%);
        color: white;
        font-size: 1.2rem;
        font-weight: 600;
        padding: 1em 2em;
        border-radius: 12px;
        border: none;
        box-shadow: 0 4px 15px rgba(42,161,152,0.3);
        transition: all 0.3s ease;
    }
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(42,161,152,0.4);
        background: linear-gradient(135deg, #2aa198 20%, #1e8c84 100%);
    }
    .prediction {
        text-align: center;
        background: linear-gradient(145deg, #0d1117 0%, #111318 100%);
        padding: 2rem;
        margin-top: 2rem;
        border-radius: 15px;
        border: 1px solid rgba(42,161,152,0.2);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        animation: glow 2s infinite alternate;
    }
    @keyframes glow {
        from { box-shadow: 0 0 20px rgba(42,161,152,0.2); }
        to { box-shadow: 0 0 30px rgba(42,161,152,0.4); }
    }
    .prediction span {
        color: #2aa198;
        font-size: 2.4rem;
        font-weight: 700;
        display: block;
        margin-top: 1rem;
        text-shadow: 0 0 10px rgba(42,161,152,0.3);
    }
    .section-title {
        color: #2aa198;
        font-size: 1.4rem;
        margin: 1.5rem 0;
        padding-bottom: 0.8rem;
        border-bottom: 2px solid rgba(42,161,152,0.2);
        text-shadow: 0 0 8px rgba(42,161,152,0.2);
    }
    </style>
""", unsafe_allow_html=True)

# --- Logo and Title ---
st.markdown("""
    <div class="logo-container">
        <div class="logo-image">
            <img src="https://t3.ftcdn.net/jpg/08/68/42/54/240_F_868425420_sHqmiluhKdbEFW515kYrXDF9qUKAEfmu.jpg" alt="Medical Logo">
        </div>
        
    </div>
""", unsafe_allow_html=True)

# --- Title ---
st.markdown("<h1>🏥 Smart Health Insurance Calculator</h1>", unsafe_allow_html=True)

# --- Gender selection and Avatar ---
st.markdown('<div class="section-title">Select Your Profile</div>', unsafe_allow_html=True)
gender = st.selectbox('Choose Your Gender', ['Female', 'Male'])

# --- Show Avatar based on Gender ---
avatar_url = {
    'Female': "https://t4.ftcdn.net/jpg/11/66/06/77/240_F_1166067709_2SooAuPWXp20XkGev7oOT7nuK1VThCsN.jpg",
    'Male': "https://t4.ftcdn.net/jpg/12/95/43/81/240_F_1295438115_pxln0mxPsK4avOSJUmzb5PpaVmUgdTI6.jpg"
}[gender]

st.markdown(
    f"""
    <div class="avatar-container">
        <img src="{avatar_url}" alt="{gender} Avatar">
    </div>
    """,
    unsafe_allow_html=True
)

# --- Personal Information Section ---
st.markdown('<div class="section-title">📋 Personal Details</div>', unsafe_allow_html=True)
with st.container():
    col1, col2 = st.columns(2)
    with col1:
        age = st.slider('Your Age', 5, 80, 25)
    with col2:
        children = st.slider('Number of Dependents', 0, 5, 0)
    bmi = st.slider('Body Mass Index (BMI)', 5.0, 100.0, 25.0)

# --- Additional Information Section ---
st.markdown('<div class="section-title">🌟 Lifestyle & Location</div>', unsafe_allow_html=True)
with st.container():
    col1, col2 = st.columns(2)
    with col1:
        smoker = st.selectbox('Smoking Status', ['No', 'Yes'])
    with col2:
        region = st.selectbox('Your Region', ['SouthEast', 'SouthWest', 'NorthEast', 'NorthWest'])

# --- Predict ---
if st.button('Calculate My Premium'):
    gender_encoded = 0 if gender == 'Female' else 1
    smoker_encoded = 1 if smoker == 'Yes' else 0
    region_encoded = ['SouthEast', 'SouthWest', 'NorthEast', 'NorthWest'].index(region)

    input_data = np.array([age, gender_encoded, bmi, children, smoker_encoded, region_encoded]).reshape(1, -1)
    predicted_premium = model.predict(input_data)[0]

    st.markdown(
        f'<div class="prediction">Your Estimated Premium<br><span>${predicted_premium:,.2f}/year</span></div>',
        unsafe_allow_html=True
    )

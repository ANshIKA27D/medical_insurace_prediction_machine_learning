import streamlit as st
import numpy as np
import joblib
import os

# Load model
model_path = os.path.join(os.path.dirname(__file__), 'train.pkl')
model = joblib.load(model_path)

# --- CSS Styling ---
st.markdown("""
    <style>
    body {
        background: #0a0c10;
        color: #e6e6e6;
        font-family: 'Segoe UI', sans-serif;
    }
    .stApp {
        background: linear-gradient(145deg, #111318 0%, #0d1117 100%);
        padding: 2.5rem;
        max-width: 1000px;
        margin: 0 auto;
        border-radius: 20px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .logo-container img {
        width: 750px;
        height: 250px;
        border-radius: 20px;
        filter: drop-shadow(0 0 15px rgba(30,144,255,0.4));
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0% { transform: scale(1); filter: brightness(1) drop-shadow(0 0 15px rgba(30,144,255,0.3)); }
        50% { transform: scale(1.05); filter: brightness(1.2) drop-shadow(0 0 20px rgba(30,144,255,0.5)); }
        100% { transform: scale(1); filter: brightness(1) drop-shadow(0 0 15px rgba(30,144,255,0.3)); }
    }
    .avatar-container {
        text-align: center;
        margin: 2rem auto;
        padding: 2rem;
        max-width: 200px;
        background: rgba(255, 255, 255, 0.03);
        border-radius: 15px;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.05);
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
    }
    .avatar-container img {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        box-shadow: 0 8px 32px rgba(30,144,255,0.3);
        border: 3px solid #1E90FF;
    }
    h1 {
        color: #1E90FF;
        text-align: center;
        font-size: 2.5rem;
        margin: 1.5rem 0;
        text-shadow: 0 0 10px rgba(30,144,255,0.3);
    }
    .section-title {
        color: #1E90FF;
        font-size: 1.4rem;
        margin: 1.5rem 0;
        padding-bottom: 0.8rem;
        border-bottom: 2px solid rgba(30,144,255,0.2);
        text-shadow: 0 0 8px rgba(30,144,255,0.2);
    }
    .stSelectbox, .stSlider {
        background: rgba(255, 255, 255, 0.03);
        border-radius: 10px;
        padding: 1.5rem;
        margin: 1rem 0;
        border: 1px solid rgba(255, 255, 255, 0.05);
    }
    .stButton>button {
        background: linear-gradient(135deg, #1E90FF 0%, #0066CC 100%);
        color: white;
        font-size: 1.2rem;
        font-weight: 600;
        padding: 1em 2em;
        border-radius: 12px;
        border: none;
        box-shadow: 0 4px 15px rgba(30,144,255,0.3);
        transition: all 0.3s ease;
    }
    .prediction {
        text-align: center;
        background: linear-gradient(145deg, #0d1117 0%, #111318 100%);
        padding: 2rem;
        margin-top: 2rem;
        border-radius: 15px;
        border: 1px solid rgba(30,144,255,0.2);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        animation: glow 2s infinite alternate;
    }
    @keyframes glow {
        from { box-shadow: 0 0 20px rgba(30,144,255,0.2); }
        to { box-shadow: 0 0 30px rgba(30,144,255,0.4); }
    }
    .prediction span {
        color: #1E90FF;
        font-size: 2.4rem;
        font-weight: 700;
        display: block;
        margin-top: 1rem;
        text-shadow: 0 0 10px rgba(30,144,255,0.3);
    }
    </style>
""", unsafe_allow_html=True)

# --- Logo and Title ---
st.markdown("""
    <div class="logo-container">
        <img src="https://t4.ftcdn.net/jpg/15/40/28/11/240_F_1540281116_eJ6YNhk5FFyWKGTJcNyEzpWkiXsMyNIq.jpg" alt="Medical Logo">
    </div>
""", unsafe_allow_html=True)

# --- Title ---
st.markdown("<h1>🏥 Smart Health Insurance Premium Predictor</h1>", unsafe_allow_html=True)

# --- Gender selection and Avatar ---
st.markdown('<div class="section-title">Select Your Profile</div>', unsafe_allow_html=True)
sex = st.selectbox("Sex", ["Female", "Male"])

# --- Show Avatar based on Gender ---
avatar_url = {
    'Female': "https://t4.ftcdn.net/jpg/11/66/06/77/240_F_1166067709_2SooAuPWXp20XkGev7oOT7nuK1VThCsN.jpg",
    'Male': "https://t4.ftcdn.net/jpg/12/95/43/81/240_F_1295438115_pxln0mxPsK4avOSJUmzb5PpaVmUgdTI6.jpg"
}[sex]

st.markdown(
    f"""
    <div class="avatar-container">
        <img src="{avatar_url}" alt="{sex} Avatar">
    </div>
    """,
    unsafe_allow_html=True
)

# --- Personal Details Section ---
st.markdown('<div class="section-title">📋 Personal Details</div>', unsafe_allow_html=True)
with st.container():
    col1, col2 = st.columns(2)
    with col1:
        age = st.slider("Age", 18, 65, 30)
    with col2:
        children = st.slider("Number of Children", 0, 5, 0)
    bmi = st.slider("BMI", 10.0, 50.0, 25.0)

# --- Lifestyle & Region Section ---
st.markdown('<div class="section-title">🌟 Lifestyle & Region</div>', unsafe_allow_html=True)
with st.container():
    col1, col2 = st.columns(2)
    with col1:
        smoker = st.selectbox("Do you smoke?", ["No", "Yes"])
    with col2:
        region = st.selectbox("Region", ["northeast", "northwest", "southeast", "southwest"])

# --- Prediction ---
if st.button("💡 Calculate Premium"):
    sex_male = 1 if sex == "Male" else 0
    smoker_yes = 1 if smoker == "Yes" else 0

    region_northwest = 1 if region == "northwest" else 0
    region_southeast = 1 if region == "southeast" else 0
    region_southwest = 1 if region == "southwest" else 0

    input_data = np.array([
        age,
        sex_male,
        bmi,
        children,
        smoker_yes,
        region_northwest,
        region_southeast,
        region_southwest
    ])

    prediction = model.predict(input_data.reshape(1, -1))[0]
    st.markdown(
        f'<div class="prediction">Your Estimated Premium<br><span>${prediction:,.2f}/year</span></div>',
        unsafe_allow_html=True
    )
